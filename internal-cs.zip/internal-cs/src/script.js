let stopwatchInterval;
let startTime;
let endTime;
let workoutStartTime;
let workouts = [];

const exercisesWithEquipment = {
    "Bicep Curl": ["Dumbbells", "Barbell", "Cable"],
    "Calf Raise": ["Dumbbells", "Barbell", "Cable", "Machine", "Bodyweight"],
    "Chest Fly": ["Dumbbells", "Cable", "Machine"],
    "Decline Chest Press": ["Dumbbells", "Barbell", "Cable", "Machine"],
    "Deadlift": ["Dumbbells", "Barbell", "Cable", "Machine"],
    "Dip": ["Machine", "Bodyweight"],
    "Face Pull": ["Cable"],
    "Flat Chest Press": ["Dumbbells", "Barbell", "Cable", "Machine"],
    "Hammer Curl": ["Dumbbells", "Cable"],
    "Incline Chest Press": ["Dumbbells", "Barbell", "Cable", "Machine"],
    "Incline Curl": ["Dumbbells", "Cable", "Machine"],
    "Lat Pulldown": ["Cable", "Machine"],
    "Lat Pullover": ["Dumbbells", "Barbell", "Cable"],
    "Lateral Raise": ["Dumbbells", "Cable", "Machine"],
    "Leg Curl": ["Machine"],
    "Leg Press": ["Machine"],
    "Lunge": ["Dumbbells", "Barbell", "Bodyweight"],
    "Overhead Extension": ["Dumbbells", "Barbell", "Cable"],
    "Overhead Press": ["Dumbbells", "Barbell", "Cable", "Machine"],
    "Preacher Curl": ["Dumbbells", "Barbell", "Cable", "Machine"],
    "Pull Up": ["Machine", "Bodyweight"],
    "Push Up": ["Bodyweight"],
    "Reverse Curl": ["Dumbbells", "Barbell", "Cable"],
    "Reverse Fly": ["Dumbbells", "Cable", "Machine"],
    "Row": ["Dumbbells", "Barbell", "Cable", "Machine"],
    "Russian Twist": ["Bodyweight"],
    "Seated Leg Curl": ["Machine"],
    "Shrug": ["Dumbbells", "Barbell", "Cable", "Machine"],
    "Sit Up": ["Bodyweight"],
    "Skullcrushers": ["Dumbbells", "Barbell", "Cable"],
    "Squat": ["Dumbbells", "Barbell", "Machine", "Bodyweight"],
    "Tricep Pushdown": ["Cable"],
    "Wrist Curl": ["Dumbbells", "Barbell", "Cable"],
    "Wrist extension": ["Dumbbells", "Barbell", "Cable"]
};

document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("signInButton").addEventListener("click", signIn);
    document.getElementById("startWorkoutButton").addEventListener("click", startWorkout);
    document.getElementById("doneButton").addEventListener("click", addExercise);
    document.getElementById("historyButton").addEventListener("click", viewHistory);
    document.getElementById("endWorkoutButton").addEventListener("click", endWorkout);
    document.getElementById("backButton").addEventListener("click", backToHome);
    document.getElementById("backToHomeButton2").addEventListener("click", backToHome);

    populateExerciseSelect();
});

function populateExerciseSelect() {
    const exerciseSelect = document.getElementById("exerciseSelect");
    Object.keys(exercisesWithEquipment).sort().forEach(exercise => {
        const option = document.createElement("option");
        option.value = exercise;
        option.textContent = exercise;
        exerciseSelect.appendChild(option);
    });
}

function signIn() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    // Add your sign-in logic here
    if (username === "admin" && password === "y123") {
        document.getElementById("signInPage").classList.add("hidden");
        document.getElementById("homePage").classList.remove("hidden");
    }
}

function startWorkout() {
    workoutStartTime = new Date();
    document.getElementById("startWorkoutButton").classList.add("hidden");
    document.getElementById("endWorkoutButton").classList.remove("hidden");
    document.getElementById("workoutPage").classList.remove("hidden");
    document.getElementById("homeStopwatch").classList.remove("hidden");
    startStopwatch();
}

function addExercise() {
    const exercise = document.getElementById("exerciseSelect").value;
    const equipment = document.getElementById("equipmentSelect").value;
    const sets = document.getElementById("sets").value;
    const reps = document.getElementById("reps").value;
    const weight = document.getElementById("weight").value;
    const exerciseInfo = {
        exercise: exercise,
        equipment: equipment,
        sets: sets,
        reps: reps,
        weight: weight
    };
    workouts.push(exerciseInfo);
    clearWorkoutForm();
}

function endWorkout() {
    clearInterval(stopwatchInterval);
    endTime = new Date();
    const timeDiff = (endTime - workoutStartTime) / 1000;
    const hours = Math.floor(timeDiff / 3600);
    const minutes = Math.floor((timeDiff - hours * 3600) / 60);
    const seconds = Math.floor(timeDiff - hours * 3600 - minutes * 60);
    const formattedTime = `${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    const workoutEntry = {
        startTime: workoutStartTime.toLocaleTimeString(),
        endTime: endTime.toLocaleTimeString(),
        duration: formattedTime,
        exercises: workouts.slice()
    };
    workouts = [];
    const historyList = document.getElementById("workoutHistory");
    const workoutItem = document.createElement("li");
    workoutItem.innerHTML = `<strong>Workout started at ${workoutEntry.startTime} and ended at ${workoutEntry.endTime} (${workoutEntry.duration})</strong>`;
    historyList.appendChild(workoutItem);
    workoutEntry.exercises.forEach(exercise => {
        const exerciseItem = document.createElement("li");
        exerciseItem.textContent = `Exercise: ${exercise.exercise}, Equipment: ${exercise.equipment}, Sets: ${exercise.sets}, Reps: ${exercise.reps}, Weight: ${exercise.weight}kg`;
        historyList.appendChild(exerciseItem);
    });
    document.getElementById("endWorkoutButton").classList.add("hidden");
    document.getElementById("workoutPage").classList.add("hidden");
    document.getElementById("homeStopwatch").classList.add("hidden");
    document.getElementById("startWorkoutButton").classList.remove("hidden");
}

function viewHistory() {
    document.getElementById("homePage").classList.add("hidden");
    document.getElementById("historyPage").classList.remove("hidden");
}

function backToHome() {
    document.getElementById("historyPage").classList.add("hidden");
    document.getElementById("workoutPage").classList.add("hidden");
    document.getElementById("homePage").classList.remove("hidden");
}

function clearWorkoutForm() {
    document.getElementById("exerciseSelect").value = "";
    document.getElementById("equipmentSelect").value = "";
    document.getElementById("sets").value = "";
    document.getElementById("reps").value = "";
    document.getElementById("weight").value = "";
}

function startStopwatch() {
    let seconds = 0;
    let minutes = 0;
    let hours = 0;

    stopwatchInterval = setInterval(() => {
        seconds++;
        if (seconds === 60) {
            seconds = 0;
            minutes++;
        }
        if (minutes === 60) {
            minutes = 0;
            hours++;
        }
        const formattedTime = `${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
        document.getElementById("homeStopwatch").textContent = formattedTime;
        document.getElementById("stopwatch").textContent = formattedTime;
    }, 1000);
}

document.getElementById("exerciseSelect").addEventListener("change", function() {
    const exercise = this.value;
    const equipmentSelect = document.getElementById("equipmentSelect");
    equipmentSelect.innerHTML = "";
    if (exercisesWithEquipment.hasOwnProperty(exercise)) {
        exercisesWithEquipment[exercise].forEach(equipment => {
            const option = document.createElement("option");
            option.value = equipment;
            option.textContent = equipment;
            equipmentSelect.appendChild(option);
        });
        equipmentSelect.classList.remove("hidden");
    } else {
        equipmentSelect.classList.add("hidden");
    }
});
