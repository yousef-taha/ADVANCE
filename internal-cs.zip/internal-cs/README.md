# INTERNAL CS

A Pen created on CodePen.io. Original URL: [https://codepen.io/ymt4h4/pen/OJqZGLZ](https://codepen.io/ymt4h4/pen/OJqZGLZ).

